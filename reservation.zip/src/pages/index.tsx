import Menu from "@/Components/Menu";
import Nav from "@/Components/Nav";
import Login from "@/pages/Login";

const Home = () => {
    return (
    <>
    <Nav/>
    <Menu/>
       </>
  );
}
export default Home